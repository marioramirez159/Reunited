<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                
                <img src="<?php echo e(URL::asset('assets/images/logos/ehospital.jpeg')); ?>" alt="" height="20px">
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block text-right">
                    <img src="<?php echo e(URL::asset('assets/images/logos/clusteritmx2.jpeg')); ?>" alt="" height="15px">
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /var/www/html/resources/views/layouts/footer.blade.php ENDPATH**/ ?>